<?php

class WCBE_Api
{
    public static function get_edgetag_options()
    {
        $data = [
            ['edgetag_url' => esc_url(get_option('edgetag_url'))],
            ['edgetag_selectors' => esc_html(get_option('edgetag_selectors'))],
            ['edgetag_script' => get_option('edgetag_script')],
        ];
        return wp_send_json($data);
    }

    public static function set_edgetag_options()
    {
        if (!isset($_POST['data'])) {
            return wp_send_json_error('Please check values', 400);
        }

        $edgetag_url = esc_url_raw($_POST['data']['edgetag_url']);
        $edgetag_selectors = sanitize_text_field($_POST['data']['edgetag_selectors']);

        $allowed_html = []; // No HTML allowed
        $edgetag_script = wp_kses(wp_unslash($_POST['data']['edgetag_script']), $allowed_html);

        if (!self::validate_form($edgetag_selectors, $edgetag_url)) {
            update_option('edgetag_selectors', $edgetag_selectors);
            update_option('edgetag_url', $edgetag_url);
            update_option('edgetag_script', $edgetag_script);

            return wp_send_json_success('Options updated');
        } else {
            return wp_send_json_error('Please check values', 400);
        }
    }

    private static function validate_form($url, $selectors)
    {
        $is_selectors_valid = is_string($selectors) && !empty(trim($selectors));
        $is_url_valid = filter_var($url, FILTER_VALIDATE_URL);

        return $is_selectors_valid && $is_url_valid;
    }
}
