<?php

/**
 * @link              https://blotout.io/
 * @since             1.0.0
 * @package           Bloutout_EdgeTag
 *
 * @wordpress-plugin
 * Plugin Name:       Blotout EdgeTag
 * Plugin URI:        https://app.edgetag.io
 * Description:       EdgeTag integration plugin for WooCommerce
 * Version:           1.2.0
 * Author:            Blotout
 * Author URI:        https://blotout.io/
 * License:           GPL-2.0+
 * License URI:       http://www.gnu.org/licenses/gpl-2.0.txt
 * Text Domain:       blotout-edge-tag
 * Domain Path:       /languages
 */

if (!defined('ABSPATH')) exit;

define('BE_VERSION', '1.2.0');

if (!defined('BE_PATH')) {
    define('BE_PATH', plugins_url('', __FILE__));
}

if (!defined('BE_CLASS_PATH')) {
    define('BE_CLASS_PATH', plugin_dir_path(__FILE__) . 'includes/');
}

if (!defined('BE_PUBLIC_JS_URL')) {
    define('BE_PUBLIC_JS_URL', plugins_url('public/js/', __FILE__));
}

function be_activate_edgetag_wc_integration()
{
    require_once plugin_dir_path(__FILE__) . 'includes/class-be-activator.php';
    BE_Activator::activate();
}

function be_deactivate_edgetag_wc_integration()
{
    require_once plugin_dir_path(__FILE__) . 'includes/class-be-deactivator.php';
    BE_Deactivator::deactivate();
}

register_activation_hook(__FILE__, 'be_activate_edgetag_wc_integration');
register_deactivation_hook(__FILE__, 'be_deactivate_edgetag_wc_integration');

require plugin_dir_path(__FILE__) . 'includes/class-be-main.php';

require BE_CLASS_PATH . 'class-be-tag.php';

function be_run_plugin()
{
    $plugin = new Bloutout_EdgeTag();
    $plugin->run();
}
be_run_plugin();
