jQuery(($) => {
    $(document).on('click', '.single_add_to_cart_button', function() {
        const quantity = $('input.qty').val() || 1;
        let contents;

        let price = addedProduct.item_price;
        let variantId = '';

        if (addedProduct.variation) {
            // Get selected variation ID
            variantId = $('input[name="variation_id"]').val();
            price = parseFloat(addedProduct.variation_prices[variantId]);
        }

        contents = [{
            id: addedProduct.id.toString(),
            variantId,
            quantity: parseInt(quantity),
            item_price: parseFloat(parseFloat(price).toFixed(addedProduct.siteData.price_decimal)),
            title: addedProduct.title,
            category: addedProduct.category,
            image: addedProduct.image,
            url: addedProduct.url
        }];

        const total = parseFloat(parseFloat(quantity * contents[0].item_price).toFixed(addedProduct.siteData.price_decimal));

        edgetag('tag', 'AddToCart', {
            currency: addedProduct.siteData.currency,
            value: total,
            contents: contents
        });
    });
});
