jQuery(($) => {
    const product = productData;
    const productPrice = parseFloat(parseFloat(product.item_price).toFixed(product.siteData.price_decimal));
    const quantity = $(product.siteData.quantity_selector).val();
    const total = parseFloat(parseFloat(quantity * productPrice).toFixed(product.siteData.price_decimal));

    edgetag('tag', 'ViewContent', {
        contents: [{
            id: product.id.toString(),
            quantity: parseInt(quantity),
            item_price: productPrice,
            title: product.title,
            category: product.category,
            image: product.image,
            url: product.url
        }],
        currency: product.siteData.currency,
        value: total,
    });
});