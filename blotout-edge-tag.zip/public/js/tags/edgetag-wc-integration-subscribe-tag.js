jQuery(document).ready(function($) {
    if (!subscribeSelectors) {
        return
    }

    $.each(subscribeSelectors, function(index, selector) {
        $(document).on('submit', selector, function() {
            const email = $(this).find('input[type="email"]').val();
            if (email) {
                processEmail(email);
            }
        });
    });

});


function processEmail(email) {
    edgetag('user', 'email', email);
    edgetag('tag', 'Subscribe');
}

window.addEventListener("klaviyoForms", function(e) {
    if (e.detail.type !== 'submit') {
        return
    }

    const email = e.detail.metaData.$email;
    const phone = e.detail.metaData.$phone_number;

    if (email) {
        processEmail(email);
    }

    if (phone) {
        edgetag('user', 'phone', phone);
    }
});