jQuery(() => {
    const currency = purchaseData.currency;
    const purchaseProductData = purchaseData.productData;
    const purchaseUserData = purchaseData.userData;
    const total = parseFloat(parseFloat(purchaseData.value).toFixed(purchaseData.price_decimals));

    const contents = purchaseProductData.map(function(product) {
        return {
            id: product.id.toString(),
            quantity: product.quantity,
            item_price: parseFloat(parseFloat(product.price).toFixed(purchaseData.price_decimals)),
            title: product.title,
            category: product.categories,
            image: product.featured_image_url,
            url: product.product_url
        };
    });

    edgetag('data', {
        'email': purchaseUserData.email,
        'phone': purchaseUserData.phone,
        'firstName': purchaseUserData.first_name,
        'lastName': purchaseUserData.last_name,
    });

    edgetag('tag', 'Purchase', {
        currency: currency,
        value: total,
        orderId: purchaseData.orderId,
        eventId: purchaseData.orderId,
        contents: contents
    });
});
