<?php

class BE_Product
{
    private $product;
    public $id;
    public $title;
    public $price;
    public $image;
    public $url;
    public $category = '';
    public $is_variation = false;
    public $variation_prices = array();

    public function __construct(WC_Product $product)
    {
        $this->product = $product;

        if (version_compare(WC()->version, '3.0', '>')) {
            $this->get_new_product();
        } else {
            $this->get_old_product();
        }

        $this->title = esc_js($this->title);
        $this->category = esc_js($this->category);
        $this->image = esc_url($this->image);
        $this->url = esc_url($this->url);
    }

    private function get_old_product()
    {
        $this->id = $this->product->id;
        $this->title = $this->product->get_title();
        $this->price = $this->product->get_price();
        $this->image = wp_get_attachment_url($this->product->get_image_id());
        $this->url = get_permalink($this->id);
        $this->category = $this->product->get_categories();
    }

    private function get_new_product()
    {
        $this->id = $this->product->get_id();
        $this->title = $this->product->get_title();
        $this->price = $this->product->get_price();
        $this->image = wp_get_attachment_url($this->product->get_image_id());
        $this->url = get_permalink($this->id);

        $categories = get_the_terms($this->id, 'product_cat');
        if (empty($categories)) {
            $categories = wp_get_post_terms($this->id, 'product_cat');
        }

        if (!empty($categories)) {
            $category_names = array();
            foreach ($categories as $category) {
                $category_names[] = $category->name;
            }
            $this->category = implode(', ', $category_names);
        }

        $this->is_variation = $this->product->is_type('variable');
        if ($this->is_variation) {
            $available_variations = $this->product->get_available_variations();
            foreach ($available_variations as $variation) {
                $variation_id = $variation['variation_id'];
                $variation_product = wc_get_product($variation_id);
                $this->variation_prices[$variation_id] = $variation_product->get_price();
            }
        }
    }
}
