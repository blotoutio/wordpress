=== EdgeTag ===
Contributors: wpmsi
Tags: edgetag
Requires at least: 4.7.0
Tested up to: 6.4
Stable tag: 1.2.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html


== Changelog ==
= 1.2.0 =
* WordPress repository requirements met
* Appsero removed

= 1.1.17 =
* Fixed order tag not sending order items

= 1.1.16 =
* Added support for older versions of the plugin
