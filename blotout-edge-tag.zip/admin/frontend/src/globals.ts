// globals.js

declare var wcbe_base_url: string;
export const baseUrl = wcbe_base_url;

declare var wcbe_assets_url: string;
export const assetsUrl = wcbe_assets_url;