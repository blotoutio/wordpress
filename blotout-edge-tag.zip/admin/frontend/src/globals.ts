// globals.js

declare var edgetag_base_url: string;
export const baseUrl = edgetag_base_url;

declare var edgetag_assets_url: string;
export const assetsUrl = edgetag_assets_url;